chrome.tabs.onUpdated.addListener((tabId,changeInfo,tab) => {
  if (tab.url.indexOf('https://x.com') > -1) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content-script.js'],
    });
  }
});