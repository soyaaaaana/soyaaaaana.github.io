x.comからtwitter.comに転送する拡張機能

【ファイルの内容】
manifest.json             - バージョンとかタイトルとか説明とか…content-script.jsを動かしている。
manifest_background.json  - background.jsをバックグラウンドで動かしている。
content-script.js         - twitter.comに変更するための処理。簡単に言えばURLを変えてるだけ。
background.js             - URLが変更されたらcontent-script.jsを実行する。
