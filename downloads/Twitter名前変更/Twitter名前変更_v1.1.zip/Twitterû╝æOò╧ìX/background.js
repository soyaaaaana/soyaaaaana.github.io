/*chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.portName === "storage") {
    if (message.type === "get") {
      chrome.storage.local.get(message.key, (items) => {
        sendResponse({ type: "get", value: items[message.key] });
      });
    } else if (message.type === "set") {
      chrome.storage.local.set({ [message.key]: message.value }, () => {
        sendResponse({ type: "set", success: true });
      });
    }
  }
});*/
/*
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === 'getId') {
    chrome.storage.local.get(['id'], function(result) {
      sendResponse(result.id);
    });
    return true;
  }
  else if (message.type === 'getName') {
    chrome.storage.local.get(['name'], function(result) {
      return sendResponse(result.name);
    });
    return true;
  }
});
*/
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === 'getId') {
    chrome.storage.local.get('id', function(items) {
      sendResponse({ data: items.id });
    });
    return true;
  }
  if (message.type === 'getName') {
    chrome.storage.local.get('name', function(items) {
      sendResponse({ data: items.name });
    });
    return true;
  }
});