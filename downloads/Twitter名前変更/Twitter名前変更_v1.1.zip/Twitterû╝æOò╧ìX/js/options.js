const sleep=waitTime=>new Promise(resolve=>setTimeout(resolve,waitTime));
var appendChild = function(htmlStr, parentSelector) {
    var e;
    if (typeof htmlStr !== "string" || typeof parentSelector !== "string" || document.querySelector(parentSelector).length === 0)
      return;
    e = document.createElement('div');
    e.innerHTML = htmlStr;
    return document.querySelector(parentSelector).appendChild(e.firstChild);
  };
  window.addEventListener('DOMContentLoaded', async function() {
    document.querySelector('button.add').addEventListener('click',e=>add());
    document.querySelector('button.save').addEventListener('click', ev=>{
      var e = ev.target
      save()
    });
    document.querySelector('button.clear').addEventListener('click', ev=>{
      chrome.storage.local.clear()
      alert("設定を初期化しました。")
    });
    try
    {
      chrome.storage.local.get("id",r=>{
        if (r.id.length!=0)
          chrome.storage.local.get("name",e=>{
            for (var i=0;i<r.id.length;i++)
              add(e.name[i],r.id[i])
          })
      })
    }catch{}
    await sleep(1000)
    if(!added)add()
  });
  function addDeleteEvent(element) {
    element.addEventListener('click', ev=>{
      del(ev.target.parentNode.className)
    });
  }
  var added=false;
  function add(name="",id="") {
    var e =document.querySelector("button.add")?.style;
    if (e!=null)
      e.display = "inline-block"
    added=true;
    let length = document.querySelectorAll("div.s").length;
    var display="inline-block";
    if (length==0)display="none";
    addDeleteEvent(appendChild(`<div class="c${length+1} s">
    <label class="matter-textfield-outlined darktheme">
      <span class="matter-tooltip"><span id="tooltip" aria-hidden="true" style="font-size:12.5px;line-height:20px;margin-bottom:-4;">名前をここに入力します。</span></span>
      <input class="name" placeholder=" " style="width:85vw" value="${name}"></input>
      <span>名前</span>
    </label>
    <div style="margin-bottom: -1em;"><span class="br"></span></div>
    <label class="matter-textfield-outlined darktheme">
      <span class="matter-tooltip"><span id="tooltip" aria-hidden="true" style="font-size:12.5px;line-height:20px;margin-bottom:-4;">「@」から始まるユーザー名をここに入力します。</span></span>
      <input class="id" placeholder=" " style="width:85vw" value="${id}"></input>
      <span>ユーザー名</span>
    </label>
    <button class="matter-button-outlined darktheme del" style="margin-left:.5em;display:${display}">削除</button>
    <hr>
    <div style="margin-bottom: -1.25em;"><span class="br"></span></div>
    </div>`,"div.e").querySelector(`div.c${length+1}.s>.del`));
    if (document.querySelectorAll("div.s").length>1)
      document.querySelectorAll("button.del").forEach(e=>e.style.display="inline-block");
  }
  function del(index) {
    if (document.querySelectorAll("div.s").length>1) {
      document.querySelector("div."+index.replace(" ",".")).remove()
      if (document.querySelectorAll("div.s").length<=1)
        document.querySelector("button.del").style.display="none";
    }
  }
  function save() {
    var value = []
    document.querySelectorAll("input.id").forEach(e=>value.push(e.value));
    chrome.storage.local.set({"id":[value]}).then(() => {
      var value2 = []
      document.querySelectorAll("input.name").forEach(e=>value2.push(e.value));
      chrome.storage.local.set({"name":[value2]}).then(() => {
        console.log("Saving completed!");
        alert("設定を保存しました。")
      });
    });
  }